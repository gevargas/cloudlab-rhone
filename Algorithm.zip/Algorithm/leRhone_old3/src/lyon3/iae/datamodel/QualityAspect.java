package lyon3.iae.datamodel;

public class QualityAspect {
	private String measure;
	private String op;
	private String value;
	
	public String getMeasure() {
		return measure;
	}
	public void setMeasure(String measure) {
		this.measure = measure;
	}
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String toString(){
		return measure + " " + op + " " + value + " ";
	}
}
