package antlr.debug;

/**
 * This type was created in VisualAge.
 */
public interface DebuggingParser {


	public String getRuleName(int n);
	public String getSemPredName(int n);
}
