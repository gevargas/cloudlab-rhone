/*
 * Created on 20.01.2005
 */
package minicon;

import datalog.DatalogQuery;

/**
 * @author Kevin
 */

public class ANTLRParser {

    private DatalogQuery createQuery(Object parsedInput) {
        return null;
    }

    private DatalogQuery createView(Object parsedInput) {
        return null;
    }

}
